/*
 * ARTICo³ Tutorial -- Hello, World!
 *
 * Author: Alfonso Rodríguez <alfonso.rodriguezm@upm.es>
 * Date  : July 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h> // struct timeval, gettimeofday()
#include <time.h>     // time()
#include <math.h>     // sqrt()
#include <float.h>    // FLT_MIN
#include "artico3.h"

void matmul_sw(int size, float a[size], float b[size], float c[size]) {
    unsigned int i, j, k;
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            c[i*size + j] = 0;
            for (k = 0; k < size; k++) {
                c[i*size + j] += a[i*size + k] * b[k*size + j];
            }
        }
    }
}

int main(int argc, char* argv[]) {
    int i, j, k, i2, j2;
    struct timeval t0, tf;
    float t;

    // Initialize ARTICo³
    artico3_init();

    // Register kernel in the ARTICo³ runtime
    artico3_kernel_create("matmul", 49152, 3, 0);

    // Load hardware accelerators
    gettimeofday(&t0, NULL);
    for (i = 0; i < 4; i++) {
        artico3_load("matmul", i, 0, 0, 1);
    }
    gettimeofday(&tf, NULL);
    t = ((tf.tv_sec - t0.tv_sec) * 1000.0) + ((tf.tv_usec - t0.tv_usec) / 1000.0);
    printf("[FPGA] Elapsed time : %.6f ms\n", t);

    // Allocate memory
    float *A = malloc(512 * 512 * sizeof *A);
    float *B = malloc(512 * 512 * sizeof *B);
    float *C_sw = malloc(512 * 512 * sizeof *C_sw);
    float *C_hw = malloc(512 * 512 * sizeof *C_hw);

    // Initialize inputs
    srand(time(NULL));
    for (i = 0; i < (512 * 512); i++) {
        A[i] = 1.0 + sqrt(rand() / 1000.0);
        B[i] = 20.0 + sin(rand() / 1000.0);
    }

    // Allocate shared memory buffers (software-hardware)
    a3data_t *a = artico3_alloc(512 * 64 * sizeof *a, "matmul", "a", A3_P_I);
    a3data_t *b = artico3_alloc(512 * 64 * sizeof *b, "matmul", "b", A3_P_I);
    a3data_t *c = artico3_alloc(512 * 64 * sizeof *c, "matmul", "c", A3_P_O);

    // Block-based matrix multiplication
    gettimeofday(&t0, NULL);
    for (i = 0; i < 512; i += 64) {
        for (j = 0; j < 512; j += 64) {
            // Initialize accumulator
            for (i2 = 0; i2 < 64; i2++) {
                for (j2 = 0; j2 < 64; j2++) {
                    C_hw[((i + i2) * 512) + (j + j2)] = 0;
                }
            }
            // Copy partial inputs
            for (k = 0; k < 512; k+=64) {
                for (i2 = 0; i2 < 64; i2++) {
                    for (j2 = 0; j2 < 64; j2++) {
                        a[((i2 + k) * 64) + j2] = ftoa3(A[((i + i2) * 512) + (k + j2)]);
                        b[((i2 + k) * 64) + j2] = ftoa3(B[((k + i2) * 512) + (j + j2)]);
                    }
                }
            }
            // Perform computation
            artico3_kernel_execute("matmul", 512, 64);
            artico3_kernel_wait("matmul");
            // Copy partial output
            for (k = 0; k < 512; k+=64) {
                for (i2 = 0; i2 < 64; i2++) {
                    for (j2 = 0; j2 < 64; j2++) {
                        C_hw[((i + i2) * 512) + (j + j2)] += a3tof(c[((i2 + k)* 64) + j2]);
                    }
                }
            }
        }
    }
    gettimeofday(&tf, NULL);
    t = ((tf.tv_sec - t0.tv_sec) * 1000.0) + ((tf.tv_usec - t0.tv_usec) / 1000.0);
    printf("[ HW ] Elapsed time : %.6f ms\n", t);

    // Get golden copy
    gettimeofday(&t0, NULL);
    matmul_sw(512, A, B, C_sw);
    gettimeofday(&tf, NULL);
    t = ((tf.tv_sec - t0.tv_sec) * 1000.0) + ((tf.tv_usec - t0.tv_usec) / 1000.0);
    printf("[ SW ] Elapsed time : %.6f ms\n", t);

    // Compare results
    int errors = 0;
    float max_error = 0.0;
    for (i = 0; i < (512 * 512); i++) {
        if (fabsf(C_hw[i] - C_sw[i]) > fabsf(1e-5 * C_sw[i])) errors++;
        if (fabsf(C_sw[i]) > FLT_MIN) {
            float error = fabsf((C_hw[i] - C_sw[i]) / C_sw[i]);
            max_error = (error > max_error) ? error : max_error;
        }
    }
    printf("Found %d errors\n", errors);
    printf("Maximum relative error is %g\n", max_error);

    // Clean up system
    free(A);
    free(B);
    free(C_sw);
    free(C_hw);
    artico3_free("matmul", "a");      // artico3_alloc(512 * 64 * sizeof *a, "matmul", "a", A3_P_I);
    artico3_free("matmul", "b");      // artico3_alloc(512 * 64 * sizeof *b, "matmul", "b", A3_P_I);
    artico3_free("matmul", "c");      // artico3_alloc(512 * 64 * sizeof *c, "matmul", "c", A3_P_O);
    artico3_kernel_release("matmul"); // artico3_kernel_create("matmul", 49152, 3, 0);
    artico3_exit();                   // artico3_init();

    return 0;
}

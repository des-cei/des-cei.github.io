/*
 * ARTICo³ Tutorial -- Hello, World!
 *
 * Author: Alfonso Rodríguez <alfonso.rodriguezm@upm.es>
 * Date  : July 2019
 *
 */

#include "artico3.h"

#define SIZE (64)

A3_KERNEL(a3in_t a, a3in_t b, a3out_t c) {
    uint8_t i, j, k;
    float aux;

    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            aux = 0;
            for (k = 0; k < SIZE; k++) {
                aux += a3tof(a[i*SIZE + k]) * a3tof(b[k*SIZE + j]);
            }
            c[i*SIZE + j] = ftoa3(aux);
        }
    }
}

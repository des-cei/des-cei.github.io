/*
 * ARTICo³ Tutorial -- Register-Based Configuration
 *
 * Author: Alfonso Rodríguez <alfonso.rodriguezm@upm.es>
 * Date  : July 2019
 *
 */

#include "artico3.h"

A3_KERNEL(a3inout_t io, a3reg_t inc) {
    uint16_t i;
    float aux;

    a3reg_init(inc);

    for (i = 0; i < (65536 / 4); i++) {
        aux = a3tof(io[i]) + a3tof(*inc);
        io[i] = ftoa3(aux);
    }
}

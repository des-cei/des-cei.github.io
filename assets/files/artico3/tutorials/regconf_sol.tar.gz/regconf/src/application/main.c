/*
 * ARTICo³ Tutorial -- Register-Based Configuration
 *
 * Author: Alfonso Rodríguez <alfonso.rodriguezm@upm.es>
 * Date  : July 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h> // struct timeval, gettimeofday()
#include "artico3.h"

int main(int argc, char* argv[]) {
    int i;
    struct timeval t0, tf;
    float t;

    // Initialize ARTICo³
    artico3_init();

    // Register kernel in the ARTICo³ runtime
    artico3_kernel_create("increment", 65536, 1, 1);

    // Load hardware accelerators
    gettimeofday(&t0, NULL);
    for (i = 0; i < 4; i++) {
        artico3_load("increment", i, 0, 0, 1);
    }
    gettimeofday(&tf, NULL);
    t = ((tf.tv_sec - t0.tv_sec) * 1000.0) + ((tf.tv_usec - t0.tv_usec) / 1000.0);
    printf("[FPGA] Elapsed time : %.6f ms\n", t);

    // Allocate shared memory buffers (software-hardware)
    a3data_t *io = artico3_alloc(8 * 65536, "increment", "io", A3_P_IO);

    // Initialize inputs
    for (i = 0; i < (8 * 65536 / 4); i++) {
        io[i] = ftoa3(i);
    }

    // Print initial values
    for (i = 0; i < (8 * 65536 / 4); i++) {
        if ((i % (65536 / 4)) < 2) printf("[ t0 ] io[%6d] = %10.3f | %08x\n", i, a3tof(io[i]), io[i]);
    }

    // Write configuration register
    a3data_t wcfg[4] = {[0 ... 3] = ftoa3(4.321)};
    artico3_kernel_wcfg("increment", 0x000, wcfg);

    // Execute kernel
    gettimeofday(&t0, NULL);
    artico3_kernel_execute("increment", 8, 1);
    artico3_kernel_wait("increment");
    gettimeofday(&tf, NULL);
    t = ((tf.tv_sec - t0.tv_sec) * 1000.0) + ((tf.tv_usec - t0.tv_usec) / 1000.0);
    printf("[ HW ] Elapsed time : %.6f ms\n", t);

    // Print final values
    for (i = 0; i < (8 * 65536 / 4); i++) {
        if ((i % (65536 / 4)) < 2) printf("[ tf ] io[%6d] = %10.3f | %08x\n", i, a3tof(io[i]), io[i]);
    }

    // Clean up system
    artico3_free("increment", "io");     // artico3_alloc(16 * 65536, "increment", "io", A3_P_IO);
    artico3_kernel_release("increment"); // artico3_kernel_create("increment", 65536, 1, 1);
    artico3_exit();                      // artico3_init();

    return 0;
}
